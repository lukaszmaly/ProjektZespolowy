package MTGPackage;
import java.util.ArrayList;

import processing.core.*;


public class Effect 
{
	public enum Type{START, BOLT, SPARKLES, FRAME, ARROW}
	
	PApplet parent;
	int life;
	Type type;
	PImage img;
	PImage l1,l2,l3,l4;
	PVector v1, v2;
	int blockId;
	int arrowType=0;
	int cardId;
	int cardWidth, cardHeight;
	ArrayList<Card> Cards;
	
	Effect(PApplet p,Type t,int life)
	{
		parent=p;
		this.life=life;
		this.type=t;
		
	}
	
	
	Effect(PApplet p,Type t,int life,PVector v1,PVector v2)
	{
		parent=p;
		this.v1=v1;
		this.v2=v2;
		this.life=life;
		this.type=t;
		this.cardHeight=cardHeight;
		this.cardWidth=cardWidth;
		if(t==Type.ARROW)
		{
			img=parent.loadImage("arrows_up.png");
		}
		
	}
	
	Effect(PApplet p,Type t,int life,int cardID,int cardWidth, int cardHeight,ArrayList<Card> c)
	{
		parent=p;
		this.v1=v1;
		this.v2=v2;
		this.life=life;
		this.type=t;
		this.cardId=cardID;
		this.cardHeight=cardHeight;
		this.cardWidth=cardWidth;
		this.Cards=c;
	
		if(t==Type.BOLT)
		{
			l1=parent.loadImage("lightning1.png");
			l2=parent.loadImage("lightning2.png");
			l3=parent.loadImage("lightning3.png");
			l4=parent.loadImage("lightning4.png");
		}
	}
	
	public void drawEffect()
	{
		if(this.type==Type.ARROW)
		{
			if(arrowType==1) img=parent.loadImage("arrows_down.png");
	    float d=parent.dist(v1.x, v1.y, v2.x, v2.y);
	    if(life>0) life--;
	    
	    int h=(int)d;
	    int w=(int)(d/5);
	    if(w>80) w=80;
	    float sin=(parent.abs(v1.x-v2.x))/d;
	    float asin=parent.asin(sin);
	    parent.println(asin);
	    parent.stroke(0,0,255);
	    //parent.line(v1.x, v1.y, v2.x, v2.y);
	    
	    
	    parent.pushMatrix();
	    parent.translate(v2.x, v2.y);
	  //  parent.rotate(parent.radians(135));
	 if(v1.x<=v2.x && v1.y<=v2.y)  
	 {
		 parent.rotate(parent.PI-asin);
	//  parent.tint(255,127);
	    parent.image(img,-w/2,0,w,d);
	 }
	 else
		 if(v1.x<=v2.x && v1.y>=v2.y)  
		 {
			 parent.rotate(asin);
			 //parent.tint(255,127);
		    parent.image(img,-w/2,0,w,d);
		 } 
		 else
			 if(v1.x>=v2.x && v1.y>=v2.y)  
			 {
				 parent.rotate(-asin);
				// parent.tint(255,127);
			    parent.image(img,-w/2,0,w,d);
			 }
			 else
				 if(v1.x>=v2.x && v1.y<=v2.y)  
				 {
					 parent.rotate(parent.PI+asin);
					// parent.tint(255,127);
				    parent.image(img,-w/2,0,w,d);
				 }
	    parent.popMatrix();

	}
		else
		if(this.type==Type.BOLT)
		{
			/*
			float d=parent.dist(v1.x, v1.y, v2.x, v2.y);
		    if(life>0) life--;
		    
		    int h=(int)d;
		    int w=(int)(d/10);
		   // if(w>80) w=80;
		    float sin=(parent.abs(v1.x-v2.x))/d;
		    float asin=parent.asin(sin);
		    parent.image(img,100,100,500,600);
		*/
			Card c;
			for (int i = 0; i < Cards.size(); i++) {
				c = Cards.get(i);
				
				if (c.id == cardId) {
				
					
					
				
			
			
			//float d=parent.dist(c.loc[].x, v1.y, v2.x, v2.y);
		    if(life>0) life--;
		    /*
		    int h=cardHeight;
		    int w=cardWidth;
		   // if(w>80) w=80;
		    float sin=(parent.abs(c.loc[3].x-v2.x))/d;
		    float asin=parent.asin(sin);
		   
		    parent.stroke(0,0,255);
		    //parent.line(v1.x, v1.y, v2.x, v2.y);
		    
		    
		    parent.pushMatrix();
		    parent.translate(v2.x, v2.y);
		  //  parent.rotate(parent.radians(135));
		 if(v1.x<=v2.x && v1.y<=v2.y)  
		 {
			 parent.rotate(parent.PI-asin);
		 // parent.tint(255,127);
		   // parent.image(img,-w/2,0,w,d);
		 }
		 else
			 if(v1.x<=v2.x && v1.y>=v2.y)  
			 {
				 parent.rotate(asin);
				 //parent.tint(255,127);
			    //parent.image(img,-w/2,0,w,d);
			 } 
			 else
				 if(v1.x>=v2.x && v1.y>=v2.y)  
				 {
					 parent.rotate(-asin);
					// parent.tint(255,127);
				    //parent.image(img,-w/2,0,w,d);
				 }
				 else
					 if(v1.x>=v2.x && v1.y<=v2.y)  
					 {
						 parent.rotate(parent.PI+asin);
						// parent.tint(255,127);
					    //parent.image(img,-w/2,0,w,d);
					 }
		 parent.image(img,0,0,parent.dist(this.loc[0].x,this.loc[0].y,this.loc[1].x,this.loc[1].y),parent.dist(this.loc[2].x,this.loc[2].y,this.loc[1].x,this.loc[1].y));
			parent.popMatrix();
		    parent.popMatrix();
		    */
		   // parent.println("!!!");
			parent.pushMatrix();
			
			parent.translate(c.loc[0].x,c.loc[0].y);
			switch(c.direction)
			{
			case 1:
				parent.rotate(c.asin);
				break;
				
			case 2:
				parent.rotate(-c.asin+parent.PI);
				break;
				
			case 3:
				parent.rotate(c.asin+parent.PI);
				break;
				
			case 4:
				parent.rotate(-c.asin);
				break;
				
			default: break;
			
			}
			
			
			//parent.image(img,0,0,parent.dist(c.loc[0].x,c.loc[0].y,c.loc[1].x,c.loc[1].y),parent.dist(c.loc[2].x,c.loc[2].y,c.loc[1].x,c.loc[1].y));
			//parent.image(img, 100, 100);
			if((int)(life/2)%4==0)
			parent.image(l1, -cardWidth/2, -cardHeight/2,cardWidth*2f,cardHeight*2f);
			else
				if((int)(life/2)%4==1)
					parent.image(l2, -cardWidth/2, -cardHeight/2,cardWidth*2f,cardHeight*2f);
				else
					if((int)(life/2)%4==2)
						parent.image(l3, -cardWidth/2, -cardHeight/2,cardWidth*2f,cardHeight*2f);
					else
						if((int)(life/2)%4==3)
							parent.image(l4, -cardWidth/2, -cardHeight/2,cardWidth*2f,cardHeight*2f);
			parent.popMatrix();
			}
			}

		}
	}
	
}

